// scientific calculator
#include <iostream>
#include <cmath>
using namespace std;

int main(){
    double num, num1, num2;
    char calc;
    int square;
    
    cout << "Enter type of calculation:\n";
    cout << "a. Addition \n";
    cout << "b. Subtration \n";
    cout << "c. Multiplication \n";
    cout << "d. Division \n";
    cout << "e. Squared \n";
    cout << "f. Square root \n";
    cin >> calc;

    if (calc == 'f' || calc == 'F') {
        cout << "Enter a number: ";
        cin >> num;
        cout << "The square root of " << num << " is " << sqrt(num);
        
    } else if (calc == 'e' || calc == 'E') {
        cout << "Enter a number: ";
        cin >> num;
        square = num * num;
        cout << num << " squared is " << square;
        
    } else {
        cout << "Enter two numbers: ";
        cin >> num1;
        cin >> num2;
        
        switch (calc) {
            case 'a':
            case 'A':
            cout << "The result is: " << num1 + num2;
            break;
            
            case 'b':
            case 'B':
            cout << "The result is: " << num1 - num2;
            break;
            
            case 'c':
            case 'C':
            cout << "The result is: " << num1 * num2;
            break;
            
            case 'd':
            case 'D':
            cout << "The result is: " << num1/num2;
            break;
        }
    }
    return 0;
}